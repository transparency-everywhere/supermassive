Use this folder ONLY if you use LESS or other type of CSS minify.
If you don't use less, remove this folder.